import "./App.css";
import Login from "./pages/loginmodule/Login.jsx";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
    return <Login />;
}

export default App;
