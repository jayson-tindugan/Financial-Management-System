function Footer() {
    return <footer className="Login-Footer"></footer>;
}

export default Footer;
