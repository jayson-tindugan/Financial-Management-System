insert all login module related pages
