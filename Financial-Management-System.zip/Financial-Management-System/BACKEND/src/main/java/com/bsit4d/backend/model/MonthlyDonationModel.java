//package com.bsit4d.backend.model;
//
//public class MonthlyDonationModel {
//    private String month;
//    private Float cashInflows;
//    private Float cashOutflows;
//    private Float cashOnHands;
//
//    public String getMonth() {
//        return month;
//    }
//
//    public void setMonth(String month) {
//        this.month = month;
//    }
//
//    public Float getCashInflows() {
//        return cashInflows;
//    }
//
//    public void setCashInflows(Float cashInflows) {
//        this.cashInflows = cashInflows;
//    }
//
//    public Float getCashOutflows() {
//        return cashOutflows;
//    }
//
//    public void setCashOutflows(Float cashOutflows) {
//        this.cashOutflows = cashOutflows;
//    }
//
//    public Float getCashOnHands() {
//        return cashOnHands;
//    }
//
//    public void setCashOnHands(Float cashOnHands) {
//        this.cashOnHands = cashOnHands;
//    }
//
//    public MonthlyDonationModel(String month, Float cashInflows, Float cashOutflows, Float cashOnHands) {
//        this.month = month;
//        this.cashInflows = cashInflows;
//        this.cashOutflows = cashOutflows;
//        this.cashOnHands = cashOnHands;
//    }
//
//}
